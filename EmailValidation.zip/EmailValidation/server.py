from flask_app.controllers import emailss
from flask_app import app

if __name__ == "__main__":
    app.run(debug=True)


